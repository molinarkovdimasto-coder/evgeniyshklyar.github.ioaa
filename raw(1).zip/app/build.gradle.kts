plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
}

android {
  namespace = "com.example.systeminfo"
  compileSdk = 33

  defaultConfig {
    applicationId = "com.example.systeminfo"
    minSdk = 23
    targetSdk = 33
    versionCode = 1
    versionName = "1.0"
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  kotlinOptions {
    jvmTarget = "11"
  }
}

dependencies {
  implementation("androidx.core:core-ktx:1.10.1")
  implementation("androidx.appcompat:appcompat:1.6.1")
  implementation("com.google.android.material:material:1.9.0")
  implementation("androidx.recyclerview:recyclerview:1.3.1")
  implementation("androidx.viewpager2:viewpager2:1.0.0")
  implementation("androidx.cardview:cardview:1.0.0")
}
