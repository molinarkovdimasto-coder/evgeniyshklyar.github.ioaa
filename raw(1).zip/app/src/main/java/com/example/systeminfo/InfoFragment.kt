package com.example.systeminfo

import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.RandomAccessFile

class InfoFragment : Fragment() {

    private lateinit var category: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        category = arguments?.getString(ARG_CATEGORY) ?: "CPU"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val recyclerView = RecyclerView(requireContext())
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val items = getInfoByCategory(category)
        recyclerView.adapter = InfoAdapter(items)

        return recyclerView
    }

    private fun getInfoByCategory(category: String): List<InfoItem> {
        val items = mutableListOf<InfoItem>()
        val context = requireContext()

        when (category) {
            "CPU" -> {
                val cpuCores = Runtime.getRuntime().availableProcessors()
                val cpuFreq = getCpuMaxFreq()
                items.add(InfoItem("CPU Ядер", cpuCores.toString()))
                items.add(InfoItem("CPU Частота", "$cpuFreq MHz"))
                items.add(InfoItem("Hardware", Build.HARDWARE))
                items.add(InfoItem("Device", Build.DEVICE))
            }
            "Память" -> {
                val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val memInfo = ActivityManager.MemoryInfo()
                activityManager.getMemoryInfo(memInfo)
                val totalRam = memInfo.totalMem / (1024 * 1024)
                val freeRam = memInfo.availMem / (1024 * 1024)

                val stat = StatFs(Environment.getDataDirectory().path)
                val totalStorage = stat.totalBytes / (1024 * 1024 * 1024)
                val freeStorage = stat.availableBytes / (1024 * 1024 * 1024)

                items.add(InfoItem("RAM Всего", "$totalRam MB"))
                items.add(InfoItem("RAM Доступно", "$freeRam MB"))
                items.add(InfoItem("Storage Всего", "$totalStorage GB"))
                items.add(InfoItem("Storage Свободно", "$freeStorage GB"))
            }
            "Батарея" -> {
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val batteryLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                items.add(InfoItem("Уровень заряда", "$batteryLevel %"))
                items.add(InfoItem("Версия Android", Build.VERSION.RELEASE))
                items.add(InfoItem("Модель", Build.MODEL))
                items.add(InfoItem("Производитель", Build.MANUFACTURER))
            }
            "Камера" -> {
                items.add(InfoItem("Камера", getCameraInfo(context)))
            }
            "Сенсоры" -> {
                items.add(InfoItem("Список сенсоров", getSensorsInfo(context)))
            }
            "Сеть" -> {
                items.addAll(getNetworkInfo(context))
            }
        }
        return items
    }

    private fun getCpuMaxFreq(): String {
        return try {
            val reader = RandomAccessFile("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq", "r")
            val freq = reader.readLine().trim().toInt() / 1000
            reader.close()
            freq.toString()
        } catch (e: Exception) {
            "Неизвестно"
        }
    }

    private fun getCameraInfo(context: Context): String {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList[0]
            val characteristics = cameraManager.getCameraCharacteristics(cameraId)
            val maxRes = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
            if (maxRes != null) {
                "${maxRes.width()} x ${maxRes.height()} px"
            } else {
                "Неизвестно"
            }
        } catch (e: Exception) {
            "Не удалось получить"
        }
    }

    private fun getSensorsInfo(context: Context): String {
        return try {
            val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val sensorList = sensorManager.getSensorList(Sensor.TYPE_ALL)
            sensorList.joinToString("\n") { "• ${it.name}" }
        } catch (e: Exception) {
            "Не удалось получить"
        }
    }

    private fun getNetworkInfo(context: Context): List<InfoItem> {
        val items = mutableListOf<InfoItem>()

        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val wifiInfo = wifiManager.connectionInfo
            val ssid = wifiInfo.ssid
            val ipAddress = Formatter.formatIpAddress(wifiInfo.ipAddress)
            val macAddress = wifiInfo.macAddress
            val rssi = wifiInfo.rssi

            items.add(InfoItem("Wi-Fi SSID", ssid))
            items.add(InfoItem("IP адрес", ipAddress))
            items.add(InfoItem("MAC Wi-Fi", macAddress))
            items.add(InfoItem("Сигнал Wi-Fi", "$rssi dBm"))
        } catch (e: Exception) {
            items.add(InfoItem("Wi-Fi", "Не удалось получить"))
        }

        try {
            val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
            if (bluetoothAdapter != null) {
                val btName = bluetoothAdapter.name
                val btAddress = bluetoothAdapter.address
                items.add(InfoItem("Bluetooth имя", btName ?: "Неизвестно"))
                items.add(InfoItem("Bluetooth MAC", btAddress ?: "Неизвестно"))
            } else {
                items.add(InfoItem("Bluetooth", "Не поддерживается"))
            }
        } catch (e: Exception) {
            items.add(InfoItem("Bluetooth", "Ошибка получения"))
        }

        return items
    }

    companion object {
        private const val ARG_CATEGORY = "category"

        fun newInstance(category: String): InfoFragment {
            val fragment = InfoFragment()
            val args = Bundle()
            args.putString(ARG_CATEGORY, category)
            fragment.arguments = args
            return fragment
        }
    }
}
