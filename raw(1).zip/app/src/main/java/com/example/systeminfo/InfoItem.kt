package com.example.systeminfo

data class InfoItem(
    val title: String,
    val value: String
)
